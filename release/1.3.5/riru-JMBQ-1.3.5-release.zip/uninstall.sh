#!/sbin/sh
MODDIR=${0%/*}
